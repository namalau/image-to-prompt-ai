package com.example.imagetoprompt

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var apiKey: EditText
    private lateinit var preview: ImageView
    private lateinit var output: EditText
    private lateinit var status: TextView
    private lateinit var generate: Button
    private lateinit var language: Spinner
    private var selectedUri: Uri? = null
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            preview.setImageURI(uri)
            preview.visibility = View.VISIBLE
            status.text = "Foto berhasil dipilih. Siap dianalisis."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(248, 249, 251)
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(248, 249, 251)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("IMAGE TO PROMPT", 12, Color.rgb(99, 102, 241), true))
        page.addView(label("Ubah foto jadi prompt AI", 26, Color.rgb(24, 27, 38), true).also {
            it.setPadding(0, dp(7), 0, dp(4))
        })
        page.addView(label("Analisis detail gambar dengan Gemini.", 14, Color.rgb(105, 110, 125), false))
        page.addView(space(22))

        val keyCard = card()
        keyCard.addView(label("Gemini API Key", 15, Color.rgb(35, 39, 52), true))
        apiKey = EditText(this).apply {
            hint = "Masukkan API Key Gemini"
            textSize = 14f
            singleLine = true
            inputType = 0x00000081
            setText(prefs.getString("api_key", ""))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(246, 247, 250))
        }
        keyCard.addView(apiKey, matchWrap())
        val saveKey = Button(this).apply {
            text = "Simpan API Key"
            isAllCaps = false
            setOnClickListener {
                prefs.edit().putString("api_key", apiKey.text.toString().trim()).apply()
                status.text = "API Key disimpan di perangkat."
            }
        }
        keyCard.addView(saveKey, matchWrap())
        page.addView(keyCard)

        page.addView(space(18))
        val uploadCard = card()
        uploadCard.addView(label("Pilih gambar", 16, Color.rgb(35, 39, 52), true))
        uploadCard.addView(label("Pilih foto yang ingin kamu ubah menjadi prompt.", 13, Color.GRAY, false))
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            setBackgroundColor(Color.rgb(238, 240, 245))
        }
        val previewParams = LinearLayout.LayoutParams(-1, dp(220))
        previewParams.topMargin = dp(12)
        uploadCard.addView(preview, previewParams)
        val choose = Button(this).apply {
            text = "＋  Pilih Foto dari Galeri"
            isAllCaps = false
            setOnClickListener { picker.launch("image/*") }
        }
        uploadCard.addView(choose, matchWrap())
        page.addView(uploadCard)

        page.addView(space(16))
        val options = card()
        options.addView(label("Bahasa prompt", 15, Color.rgb(35, 39, 52), true))
        language = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("English", "Bahasa Indonesia"))
        }
        options.addView(language, matchWrap())
        page.addView(options)

        page.addView(space(14))
        generate = Button(this).apply {
            text = "✨  Generate Prompt"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(79, 70, 229))
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { generatePrompt() }
        }
        page.addView(generate, matchWrap())

        status = label("Masukkan API Key dan pilih foto untuk memulai.", 13, Color.rgb(100, 105, 120), false)
        status.gravity = Gravity.CENTER
        status.setPadding(0, dp(12), 0, dp(8))
        page.addView(status)

        val resultCard = card()
        resultCard.addView(label("Hasil prompt", 16, Color.rgb(35, 39, 52), true))
        output = EditText(this).apply {
            hint = "Hasil prompt akan muncul di sini..."
            textSize = 14f
            minLines = 7
            gravity = Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(246, 247, 250))
        }
        resultCard.addView(output, matchWrap())
        val copy = Button(this).apply {
            text = "Salin Prompt"
            isAllCaps = false
            setOnClickListener {
                val text = output.text.toString()
                if (text.isNotBlank()) {
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("AI Prompt", text))
                    status.text = "Prompt berhasil disalin."
                }
            }
        }
        resultCard.addView(copy, matchWrap())
        page.addView(resultCard)

        page.addView(space(16))
        page.addView(label("Tips: hasil terbaik didapat dari foto yang jelas dan tidak blur.", 12, Color.GRAY, false))
    }

    private fun generatePrompt() {
        val key = apiKey.text.toString().trim()
        val uri = selectedUri
        if (key.isBlank()) { status.text = "Masukkan API Key Gemini terlebih dahulu."; return }
        if (uri == null) { status.text = "Pilih foto terlebih dahulu."; return }

        generate.isEnabled = false
        generate.text = "Sedang menganalisis..."
        status.text = "Gemini sedang membaca detail gambar..."
        executor.execute {
            try {
                val bitmap = contentResolver.openInputStream(uri).use { input ->
                    BitmapFactory.decodeStream(input) ?: throw Exception("Format gambar tidak didukung.")
                }
                val scaled = scaleBitmap(bitmap, 1600)
                val stream = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 88, stream)
                val encoded = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

                val lang = if (language.selectedItemPosition == 0) "English" else "Bahasa Indonesia"
                val instruction = """
                    Analyze the uploaded image carefully and write a highly accurate, detailed image-generation prompt in $lang.
                    Describe only visible evidence. Do not invent identity, objects, text, brands, or details that cannot be seen.
                    Include: main subject and appearance, pose and expression, clothing and accessories, framing and camera angle,
                    composition, background and environment, lighting, color palette, visual style, textures, and photographic details.
                    Preserve the original scene and relationships between subjects. Be specific and natural.
                    Output only the finished prompt, with no introduction, no analysis, and no markdown heading.
                """.trimIndent()

                val body = JSONObject().apply {
                    put("contents", org.json.JSONArray().put(JSONObject().apply {
                        put("parts", org.json.JSONArray()
                            .put(JSONObject().put("text", instruction))
                            .put(JSONObject().put("inline_data", JSONObject()
                                .put("mime_type", "image/jpeg")
                                .put("data", encoded)))
                    }))
                    put("generationConfig", JSONObject().put("temperature", 0.25).put("maxOutputTokens", 1800))
                }

                val model = "gemini-2.5-flash"
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=" +
                    URLEncoder.encode(key, "UTF-8"))
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 30000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val responseText = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                conn.disconnect()
                if (code !in 200..299) {
                    val msg = try { JSONObject(responseText).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                    throw Exception(msg?.takeIf { it.isNotBlank() } ?: "Permintaan gagal (HTTP $code). Periksa API Key dan kuota.")
                }
                val json = JSONObject(responseText)
                val parts = json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                val result = buildString {
                    if (parts != null) for (i in 0 until parts.length()) {
                        val t = parts.optJSONObject(i)?.optString("text")
                        if (!t.isNullOrBlank()) append(t).append("\n")
                    }
                }.trim()
                if (result.isBlank()) throw Exception("Gemini tidak mengembalikan teks. Coba lagi.")
                runOnUiThread {
                    output.setText(result)
                    status.text = "Selesai! Prompt berhasil dibuat."
                    generate.isEnabled = true
                    generate.text = "✨  Generate Prompt"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Gagal: ${e.message ?: "Terjadi kesalahan."}"
                    generate.isEnabled = true
                    generate.text = "✨  Generate Prompt"
                }
            }
        }
    }

    private fun scaleBitmap(src: Bitmap, max: Int): Bitmap {
        val largest = maxOf(src.width, src.height)
        if (largest <= max) return src
        val ratio = max.toFloat() / largest
        return Bitmap.createScaledBitmap(src, (src.width * ratio).toInt(), (src.height * ratio).toInt(), true)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(Color.WHITE)
        elevation = dp(1).toFloat()
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
