# Image to Prompt AI

Aplikasi Android native sederhana berbasis Kotlin. Memilih gambar dari galeri, mengirim gambar ke Gemini API, lalu menghasilkan prompt rinci dalam bahasa Inggris atau Indonesia.

## Cara membuka
1. Ekstrak ZIP ini.
2. Buka folder `ImageToPromptAI` melalui Android Studio.
3. Pastikan Android SDK 35 dan JDK 17 tersedia.
4. Tunggu Gradle Sync selesai.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara menggunakan
1. Buat API Key di Google AI Studio: https://aistudio.google.com/app/apikey
2. Buka aplikasi, masukkan API Key, lalu tekan **Simpan API Key**.
3. Pilih foto, pilih bahasa prompt, dan tekan **Generate Prompt**.
4. Tekan **Salin Prompt** untuk menyalin hasil.

## Catatan keamanan
API Key disimpan lokal di SharedPreferences aplikasi dan dipakai langsung dari perangkat. Untuk aplikasi yang didistribusikan ke publik, jangan menanam API Key pribadi di APK. Gunakan backend/proxy milik sendiri dengan pembatasan kuota dan autentikasi. Pemakaian API dapat dikenai batas atau biaya sesuai akun Google AI Studio.

Model default: `gemini-2.5-flash`. Jika model tidak tersedia untuk akun/region Anda, ubah konstanta `model` di `MainActivity.kt` ke model vision yang tersedia di Google AI Studio.
